window.onload = function () {
    var element = document.getElementById('canvas');

    // add code


    


}