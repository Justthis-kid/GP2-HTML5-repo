window.onload = function() {

    let card1 = document.getElementById('card1');

    card1.addEventListener('click', function () {
        card1.classList.add('card-highlight');
    })

    let card2 = document.getElementById('card2');

    // add event listener
}

// go to and link events2.js

