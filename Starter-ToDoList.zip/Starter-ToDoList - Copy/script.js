function addTask() {
    const taskInput = document.getElementById('task-input');
    const newTask = taskInput.value.trim();
    if ( newTask == "") {
        alert("Please enter a task.");
        return;
    }
    else if (newTask !== "" ) {
        const taskList = document.getElementById('task-list');
        const listItem = document.createElement('li');
        listItem.className = 'task-item';
        listItem.textContent = newTask;
        taskList.appendChild(listItem);
        taskInput.value = "";




// const taskList = document.getElementById('task-list');
// const listItem = document.createElement('li');
// const taskSpan = document.createElement('span');
// taskSpan.textContent = taskInput;
// listItem.appendChild(taskSpan);
// taskList.appendChild(listItem);
// taskInput.value = "";
    }
}






///     if (newTask !== "") 
///         const taskList = document.getElementById('task-list');
///         const toDo = document.createElement('li');
///         toDo.className = 'task-item';
///         toDo.innerHTML = newTask;
///         taskList.appendChild(toDo);
///         taskInput.value = "";
